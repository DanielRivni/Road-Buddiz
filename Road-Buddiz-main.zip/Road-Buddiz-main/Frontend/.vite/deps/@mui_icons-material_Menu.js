"use client";
import {
  require_createSvgIcon,
  require_interopRequireDefault
} from "./chunk-BUVUQFHU.js";
import "./chunk-TPCBT4YH.js";
import "./chunk-RHOSH3ZX.js";
import "./chunk-MIMXZF5D.js";
import "./chunk-IS6YWGCK.js";
import "./chunk-2TVZKNAZ.js";
import "./chunk-6MYKSBLU.js";
import "./chunk-OO24EFQA.js";
import "./chunk-CGCCDHZJ.js";
import {
  require_jsx_runtime
} from "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import {
  __commonJS
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/icons-material/Menu.js
var require_Menu = __commonJS({
  "node_modules/@mui/icons-material/Menu.js"(exports) {
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.default = void 0;
    var _createSvgIcon = _interopRequireDefault(require_createSvgIcon());
    var _jsxRuntime = require_jsx_runtime();
    var _default = exports.default = (0, _createSvgIcon.default)((0, _jsxRuntime.jsx)("path", {
      d: "M3 18h18v-2H3zm0-5h18v-2H3zm0-7v2h18V6z"
    }), "Menu");
  }
});
export default require_Menu();
//# sourceMappingURL=@mui_icons-material_Menu.js.map
