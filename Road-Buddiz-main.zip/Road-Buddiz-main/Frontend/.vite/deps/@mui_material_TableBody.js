"use client";
import {
  TableBody_default,
  getTableBodyUtilityClass,
  tableBodyClasses_default
} from "./chunk-E5E3MQO4.js";
import "./chunk-PJ3JCBZ7.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  TableBody_default as default,
  getTableBodyUtilityClass,
  tableBodyClasses_default as tableBodyClasses
};
//# sourceMappingURL=@mui_material_TableBody.js.map
