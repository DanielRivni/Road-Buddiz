import {
  init_esm,
  useForkRef
} from "./chunk-GDTTK2E2.js";
import {
  __esm
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/material/utils/useForkRef.js
var useForkRef_default;
var init_useForkRef = __esm({
  "node_modules/@mui/material/utils/useForkRef.js"() {
    "use client";
    init_esm();
    useForkRef_default = useForkRef;
  }
});

export {
  useForkRef_default,
  init_useForkRef
};
//# sourceMappingURL=chunk-6MYKSBLU.js.map
