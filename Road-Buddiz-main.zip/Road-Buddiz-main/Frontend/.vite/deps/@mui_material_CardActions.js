"use client";
import {
  CardActions_default,
  cardActionsClasses_default,
  getCardActionsUtilityClass
} from "./chunk-JDPNPTPA.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  cardActionsClasses_default as cardActionsClasses,
  CardActions_default as default,
  getCardActionsUtilityClass
};
//# sourceMappingURL=@mui_material_CardActions.js.map
