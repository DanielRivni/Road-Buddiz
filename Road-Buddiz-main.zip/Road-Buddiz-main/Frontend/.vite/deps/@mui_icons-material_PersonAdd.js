"use client";
import {
  require_createSvgIcon,
  require_interopRequireDefault
} from "./chunk-BUVUQFHU.js";
import "./chunk-TPCBT4YH.js";
import "./chunk-RHOSH3ZX.js";
import "./chunk-MIMXZF5D.js";
import "./chunk-IS6YWGCK.js";
import "./chunk-2TVZKNAZ.js";
import "./chunk-6MYKSBLU.js";
import "./chunk-OO24EFQA.js";
import "./chunk-CGCCDHZJ.js";
import {
  require_jsx_runtime
} from "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import {
  __commonJS
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/icons-material/PersonAdd.js
var require_PersonAdd = __commonJS({
  "node_modules/@mui/icons-material/PersonAdd.js"(exports) {
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.default = void 0;
    var _createSvgIcon = _interopRequireDefault(require_createSvgIcon());
    var _jsxRuntime = require_jsx_runtime();
    var _default = exports.default = (0, _createSvgIcon.default)((0, _jsxRuntime.jsx)("path", {
      d: "M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4m-9-2V7H4v3H1v2h3v3h2v-3h3v-2zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4"
    }), "PersonAdd");
  }
});
export default require_PersonAdd();
//# sourceMappingURL=@mui_icons-material_PersonAdd.js.map
