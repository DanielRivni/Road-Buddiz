"use client";
import {
  FormControlLabel_default,
  formControlLabelClasses_default,
  getFormControlLabelUtilityClasses
} from "./chunk-OMXUHB4V.js";
import "./chunk-LNJMZYCI.js";
import "./chunk-YJU66VYE.js";
import "./chunk-MIMXZF5D.js";
import "./chunk-GPMREAAY.js";
import "./chunk-OO24EFQA.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  FormControlLabel_default as default,
  formControlLabelClasses_default as formControlLabelClasses,
  getFormControlLabelUtilityClasses
};
//# sourceMappingURL=@mui_material_FormControlLabel.js.map
