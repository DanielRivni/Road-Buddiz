"use client";
import {
  Paper_default,
  getPaperUtilityClass,
  paperClasses_default
} from "./chunk-OX3W2L3B.js";
import "./chunk-43RY5WUD.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  Paper_default as default,
  getPaperUtilityClass,
  paperClasses_default as paperClasses
};
//# sourceMappingURL=@mui_material_Paper.js.map
