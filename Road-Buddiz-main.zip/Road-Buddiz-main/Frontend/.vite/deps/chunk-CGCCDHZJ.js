import {
  init_esm
} from "./chunk-GDTTK2E2.js";
import {
  __esm
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/base/composeClasses/index.js
var init_composeClasses = __esm({
  "node_modules/@mui/base/composeClasses/index.js"() {
    init_esm();
  }
});

export {
  init_composeClasses
};
//# sourceMappingURL=chunk-CGCCDHZJ.js.map
