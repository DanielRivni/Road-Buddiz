"use client";
import {
  TableHead_default,
  getTableHeadUtilityClass,
  tableHeadClasses_default
} from "./chunk-VFUTXMIX.js";
import "./chunk-PJ3JCBZ7.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  TableHead_default as default,
  getTableHeadUtilityClass,
  tableHeadClasses_default as tableHeadClasses
};
//# sourceMappingURL=@mui_material_TableHead.js.map
