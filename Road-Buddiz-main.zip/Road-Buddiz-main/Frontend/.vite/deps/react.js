import {
  require_react
} from "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export default require_react();
//# sourceMappingURL=react.js.map
