"use client";
import {
  require_createSvgIcon,
  require_interopRequireDefault
} from "./chunk-BUVUQFHU.js";
import "./chunk-TPCBT4YH.js";
import "./chunk-RHOSH3ZX.js";
import "./chunk-MIMXZF5D.js";
import "./chunk-IS6YWGCK.js";
import "./chunk-2TVZKNAZ.js";
import "./chunk-6MYKSBLU.js";
import "./chunk-OO24EFQA.js";
import "./chunk-CGCCDHZJ.js";
import {
  require_jsx_runtime
} from "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import {
  __commonJS
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/icons-material/Edit.js
var require_Edit = __commonJS({
  "node_modules/@mui/icons-material/Edit.js"(exports) {
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.default = void 0;
    var _createSvgIcon = _interopRequireDefault(require_createSvgIcon());
    var _jsxRuntime = require_jsx_runtime();
    var _default = exports.default = (0, _createSvgIcon.default)((0, _jsxRuntime.jsx)("path", {
      d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z"
    }), "Edit");
  }
});
export default require_Edit();
//# sourceMappingURL=@mui_icons-material_Edit.js.map
