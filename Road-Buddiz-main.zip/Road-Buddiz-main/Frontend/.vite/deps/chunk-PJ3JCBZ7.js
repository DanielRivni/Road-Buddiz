import {
  require_react
} from "./chunk-UM3JHGVO.js";
import {
  __toESM
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/material/Table/Tablelvl2Context.js
var React = __toESM(require_react());
var Tablelvl2Context = React.createContext();
if (true) {
  Tablelvl2Context.displayName = "Tablelvl2Context";
}
var Tablelvl2Context_default = Tablelvl2Context;

export {
  Tablelvl2Context_default
};
//# sourceMappingURL=chunk-PJ3JCBZ7.js.map
