import {
  require_react
} from "./chunk-UM3JHGVO.js";
import {
  __toESM
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/material/Table/TableContext.js
var React = __toESM(require_react());
var TableContext = React.createContext();
if (true) {
  TableContext.displayName = "TableContext";
}
var TableContext_default = TableContext;

export {
  TableContext_default
};
//# sourceMappingURL=chunk-QIUP3YAG.js.map
