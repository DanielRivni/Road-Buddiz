"use client";
import {
  require_createSvgIcon,
  require_interopRequireDefault
} from "./chunk-BUVUQFHU.js";
import "./chunk-TPCBT4YH.js";
import "./chunk-RHOSH3ZX.js";
import "./chunk-MIMXZF5D.js";
import "./chunk-IS6YWGCK.js";
import "./chunk-2TVZKNAZ.js";
import "./chunk-6MYKSBLU.js";
import "./chunk-OO24EFQA.js";
import "./chunk-CGCCDHZJ.js";
import {
  require_jsx_runtime
} from "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import {
  __commonJS
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/icons-material/Delete.js
var require_Delete = __commonJS({
  "node_modules/@mui/icons-material/Delete.js"(exports) {
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.default = void 0;
    var _createSvgIcon = _interopRequireDefault(require_createSvgIcon());
    var _jsxRuntime = require_jsx_runtime();
    var _default = exports.default = (0, _createSvgIcon.default)((0, _jsxRuntime.jsx)("path", {
      d: "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6zM19 4h-3.5l-1-1h-5l-1 1H5v2h14z"
    }), "Delete");
  }
});
export default require_Delete();
//# sourceMappingURL=@mui_icons-material_Delete.js.map
