"use client";
import {
  Typography_default,
  getTypographyUtilityClass,
  typographyClasses_default
} from "./chunk-GPMREAAY.js";
import "./chunk-OO24EFQA.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  Typography_default as default,
  getTypographyUtilityClass,
  typographyClasses_default as typographyClasses
};
//# sourceMappingURL=@mui_material_Typography.js.map
