"use client";
import {
  Table_default,
  getTableUtilityClass,
  tableClasses_default
} from "./chunk-TS4LXCVH.js";
import "./chunk-QIUP3YAG.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  Table_default as default,
  getTableUtilityClass,
  tableClasses_default as tableClasses
};
//# sourceMappingURL=@mui_material_Table.js.map
