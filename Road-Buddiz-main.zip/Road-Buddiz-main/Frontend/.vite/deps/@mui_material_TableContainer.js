"use client";
import {
  TableContainer_default,
  getTableContainerUtilityClass,
  tableContainerClasses_default
} from "./chunk-7WJXG5R2.js";
import "./chunk-CGCCDHZJ.js";
import "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import "./chunk-CEQRFMJQ.js";
export {
  TableContainer_default as default,
  getTableContainerUtilityClass,
  tableContainerClasses_default as tableContainerClasses
};
//# sourceMappingURL=@mui_material_TableContainer.js.map
