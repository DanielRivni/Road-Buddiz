"use client";
import {
  require_createSvgIcon,
  require_interopRequireDefault
} from "./chunk-BUVUQFHU.js";
import "./chunk-TPCBT4YH.js";
import "./chunk-RHOSH3ZX.js";
import "./chunk-MIMXZF5D.js";
import "./chunk-IS6YWGCK.js";
import "./chunk-2TVZKNAZ.js";
import "./chunk-6MYKSBLU.js";
import "./chunk-OO24EFQA.js";
import "./chunk-CGCCDHZJ.js";
import {
  require_jsx_runtime
} from "./chunk-GDTTK2E2.js";
import "./chunk-UM3JHGVO.js";
import {
  __commonJS
} from "./chunk-CEQRFMJQ.js";

// node_modules/@mui/icons-material/Logout.js
var require_Logout = __commonJS({
  "node_modules/@mui/icons-material/Logout.js"(exports) {
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.default = void 0;
    var _createSvgIcon = _interopRequireDefault(require_createSvgIcon());
    var _jsxRuntime = require_jsx_runtime();
    var _default = exports.default = (0, _createSvgIcon.default)((0, _jsxRuntime.jsx)("path", {
      d: "m17 7-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4z"
    }), "Logout");
  }
});
export default require_Logout();
//# sourceMappingURL=@mui_icons-material_Logout.js.map
